BLACKLINE BARBER — DEMO

Fichiers : index.html, style.css, script.js

Les photos utilisées sont des photos Pexels libres d'utilisation. Pour un vrai client, remplacez les coordonnées fictives et utilisez les photos fournies par le commerce lorsque possible.

Photos sources :
- https://www.pexels.com/photo/barber-cutting-client-hair-19664876/
- https://www.pexels.com/photo/barber-cutting-person-s-hair-2076930/
- https://www.pexels.com/photo/the-interior-of-a-barber-shop-7518728/
- https://www.pexels.com/photo/a-man-having-a-haircut-in-a-barber-shop-9992818/
- https://www.pexels.com/photo/a-man-getting-a-haircut-in-a-barbershop-7518742/
- https://www.pexels.com/photo/modern-barber-shop-interior-with-mirror-reflection-30547693/
